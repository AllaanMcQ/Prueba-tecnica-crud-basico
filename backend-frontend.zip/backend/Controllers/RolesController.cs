using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ApiCrud.Data;
using ApiCrud.Models;

namespace ApiCrud.Controllers;

[ApiController]
[Route("api/[controller]")]
public class RolesController : ControllerBase
{
    private readonly AppDbContext _context;
    public RolesController(AppDbContext context) => _context = context;

    [HttpGet]
    public async Task<IActionResult> Get() =>
        Ok(await _context.Roles.ToListAsync());

    [HttpPost]
    public async Task<IActionResult> Post(Rol rol)
    {
        if (string.IsNullOrWhiteSpace(rol.Nombre))
            return BadRequest("Nombre es obligatorio");

        _context.Add(rol);
        await _context.SaveChangesAsync();
        return Ok(rol);
    }

    [HttpPut("{id}")]
    public async Task<IActionResult> Put(int id, Rol rol)
    {
        if (id != rol.Id) return BadRequest();
        _context.Update(rol);
        await _context.SaveChangesAsync();
        return NoContent();
    }

    [HttpDelete("{id}")]
    public async Task<IActionResult> Delete(int id)
    {
        var rol = await _context.Roles.FindAsync(id);
        if (rol == null) return NotFound();
        _context.Remove(rol);
        await _context.SaveChangesAsync();
        return NoContent();
    }
}
