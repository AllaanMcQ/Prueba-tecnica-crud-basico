using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ApiCrud.Data;
using ApiCrud.Models;

namespace ApiCrud.Controllers;

[ApiController]
[Route("api/[controller]")]
public class VariablesController : ControllerBase
{
    private readonly AppDbContext _context;
    public VariablesController(AppDbContext context) => _context = context;

    [HttpGet]
    public async Task<IActionResult> Get() =>
        Ok(await _context.Variables.ToListAsync());

    [HttpPost]
    public async Task<IActionResult> Post(Variable variable)
    {
        if (string.IsNullOrWhiteSpace(variable.Nombre))
            return BadRequest("Nombre es obligatorio");

        // Validar que tipo sea 1, 2 o 3 (texto, numérico, booleano)
        if (variable.Tipo != 1 && variable.Tipo != 2 && variable.Tipo != 3)
            return BadRequest("Tipo es obligatorio (1=Texto, 2=Numérico, 3=Booleano)");

        if (string.IsNullOrWhiteSpace(variable.Valor))
            return BadRequest("Valor es obligatorio");

        _context.Add(variable);
        await _context.SaveChangesAsync();
        return Ok(variable);
    }

    [HttpPut("{id}")]
    public async Task<IActionResult> Put(int id, Variable variable)
    {
        if (id != variable.Id) return BadRequest();
        _context.Update(variable);
        await _context.SaveChangesAsync();
        return NoContent();
    }

    [HttpDelete("{id}")]
    public async Task<IActionResult> Delete(int id)
    {
        var variable = await _context.Variables.FindAsync(id);
        if (variable == null) return NotFound();
        _context.Remove(variable);
        await _context.SaveChangesAsync();
        return NoContent();
    }
}
