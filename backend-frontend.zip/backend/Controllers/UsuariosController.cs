using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ApiCrud.Data;
using ApiCrud.Models;
using System.ComponentModel.DataAnnotations;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ApiCrud.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class UsuariosController : ControllerBase
    {
        private readonly AppDbContext _context;
        public UsuariosController(AppDbContext context) => _context = context;

        // DTO interno para respuesta sin ciclos
        public class UsuarioDto
        {
            public int Id { get; set; }
            public string Nombre { get; set; }
            public string Email { get; set; }
            public int RolId { get; set; }
            public string RolNombre { get; set; }
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<UsuarioDto>>> Get()
        {
            var usuarios = await _context.Usuarios
                .Include(u => u.Rol)
                .Select(u => new UsuarioDto
                {
                    Id = u.Id,
                    Nombre = u.Nombre,
                    Email = u.Email,
                    RolId = u.RolId,
                    RolNombre = u.Rol.Nombre
                })
                .ToListAsync();

            return Ok(usuarios);
        }

        [HttpPost]
        public async Task<IActionResult> Post(Usuario usuario)
        {
            if (!new EmailAddressAttribute().IsValid(usuario.Email))
                return BadRequest("Email inválido");
            if (string.IsNullOrWhiteSpace(usuario.Nombre))
                return BadRequest("Nombre es obligatorio");
            if (usuario.RolId <= 0)
                return BadRequest("RolId inválido");

            _context.Add(usuario);
            await _context.SaveChangesAsync();

            // Responder con DTO
            var usuarioDto = new UsuarioDto
            {
                Id = usuario.Id,
                Nombre = usuario.Nombre,
                Email = usuario.Email,
                RolId = usuario.RolId,
                RolNombre = (await _context.Roles.FindAsync(usuario.RolId))?.Nombre ?? ""
            };

            return Ok(usuarioDto);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Put(int id, Usuario usuario)
        {
            if (id != usuario.Id) return BadRequest();

            if (!new EmailAddressAttribute().IsValid(usuario.Email))
                return BadRequest("Email inválido");
            if (string.IsNullOrWhiteSpace(usuario.Nombre))
                return BadRequest("Nombre es obligatorio");
            if (usuario.RolId <= 0)
                return BadRequest("RolId inválido");

            _context.Update(usuario);
            await _context.SaveChangesAsync();
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var usuario = await _context.Usuarios.FindAsync(id);
            if (usuario == null) return NotFound();
            _context.Remove(usuario);
            await _context.SaveChangesAsync();
            return NoContent();
        }
    }
}
