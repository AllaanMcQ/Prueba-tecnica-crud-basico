public class UsuarioDto
{
    public int Id { get; set; }
    public required string Nombre { get; set; }
    public required string Email { get; set; }
    public int RolId { get; set; }
    public required string RolNombre { get; set; }
}
