public class Variable
{
    public int Id { get; set; }
    public string Nombre { get; set; } = "";
    public string Valor { get; set; } = "";
    public int Tipo { get; set; } // 1=texto, 2=numérico, 3=booleano
}
