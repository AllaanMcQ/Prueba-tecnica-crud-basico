import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { VariableService, Variable } from '../services/variable.service';

@Component({
  selector: 'app-variables',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <form (ngSubmit)="guardar()" style="margin-bottom:16px;">
      <input [(ngModel)]="variable.nombre" name="nombre" placeholder="Nombre" required>
      <input [(ngModel)]="variable.valor" name="valor" placeholder="Valor" required>
      <input 
        [(ngModel)]="variable.tipo" 
        name="tipo" 
        type="number" 
        min="1" 
        max="99999" 
        placeholder="Tipo (número)" 
        required>
      <button type="submit">{{ editando ? 'Actualizar' : 'Agregar' }}</button>
      <button type="button" (click)="cancelar()" *ngIf="editando">Cancelar</button>
    </form>
    <table border="1" style="width:100%;">
      <tr>
        <th>Id</th>
        <th>Nombre</th>
        <th>Valor</th>
        <th>Tipo <br>(Numerico)</th>
        <th>Acciones</th>
      </tr>
      <tr *ngFor="let v of variables">
        <td>{{ v.id }}</td>
        <td>{{ v.nombre }}</td>
        <td>{{ v.valor }}</td>
        <td>{{ v.tipo }}</td>
        <td>
          <button (click)="editar(v)">Editar</button>
          <button (click)="eliminar(v.id)">Eliminar</button>
        </td>
      </tr>
    </table>
  `,
  styles: []
})
export class VariablesComponent {
  variables: Variable[] = [];
  variable: Variable = { id: 0, nombre: '', valor: '', tipo: 1 };
  editando = false;

  constructor(private variableSvc: VariableService) {
    this.cargarVariables();
  }

  cargarVariables() {
    this.variableSvc.listar().subscribe(data => this.variables = data);
  }

  guardar() {
    if (!this.variable.nombre.trim() || !this.variable.valor.trim() || !this.variable.tipo) {
      alert('Todos los campos son obligatorios');
      return;
    }
    // Puedes ajustar el rango aquí si solo quieres ciertos números permitidos
    if (this.variable.tipo < 1 || this.variable.tipo > 99999) {
      alert('Tipo debe ser un número entre 1 y 99999');
      return;
    }
    if (this.editando) {
      this.variableSvc.actualizar(this.variable.id, this.variable).subscribe(() => {
        this.cancelar();
        this.cargarVariables();
      });
    } else {
      this.variableSvc.crear(this.variable).subscribe(() => {
        this.cancelar();
        this.cargarVariables();
      });
    }
  }

  editar(v: Variable) {
    this.variable = { ...v };
    this.editando = true;
  }

  eliminar(id: number) {
    if (confirm('¿Eliminar variable?')) {
      this.variableSvc.eliminar(id).subscribe(() => this.cargarVariables());
    }
  }

  cancelar() {
    this.variable = { id: 0, nombre: '', valor: '', tipo: 1 };
    this.editando = false;
  }
}
