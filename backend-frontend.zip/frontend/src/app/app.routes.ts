import { Routes } from '@angular/router';
import { RolesComponent } from './roles/roles.component';
import { UsuariosComponent } from './usuarios/usuarios.component';
import { VariablesComponent } from './variables/variables.component';

export const routes: Routes = [
  { path: 'roles', component: RolesComponent },
  { path: 'usuarios', component: UsuariosComponent },
  { path: 'variables', component: VariablesComponent },
  { path: '', redirectTo: '/roles', pathMatch: 'full' }
];
