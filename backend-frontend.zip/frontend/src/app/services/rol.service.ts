import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface Rol {
  id: number;
  nombre: string;
}

@Injectable({ providedIn: 'root' })
export class RolService {
  api = 'http://localhost:5010/api/roles';
  constructor(private http: HttpClient) {}

  listar(): Observable<Rol[]> { return this.http.get<Rol[]>(this.api); }
  crear(rol: Rol) { return this.http.post(this.api, rol); }
  actualizar(id: number, rol: Rol) { return this.http.put(`${this.api}/${id}`, rol); }
  eliminar(id: number) { return this.http.delete(`${this.api}/${id}`); }
}
