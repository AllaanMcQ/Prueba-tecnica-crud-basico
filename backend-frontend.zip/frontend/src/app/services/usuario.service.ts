import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface Usuario {
  id: number;
  nombre: string;
  email: string;
  rolId: number;
  rol?: any;
}

@Injectable({ providedIn: 'root' })
export class UsuarioService {
  api = 'http://localhost:5010/api/usuarios';
  constructor(private http: HttpClient) {}
  listar(): Observable<Usuario[]> { return this.http.get<Usuario[]>(this.api); }
  crear(u: Usuario) { return this.http.post(this.api, u); }
  actualizar(id: number, u: Usuario) { return this.http.put(`${this.api}/${id}`, u); }
  eliminar(id: number) { return this.http.delete(`${this.api}/${id}`); }
}
