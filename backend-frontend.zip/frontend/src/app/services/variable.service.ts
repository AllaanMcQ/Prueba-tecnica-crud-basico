import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface Variable {
  id: number;
  nombre: string;
  valor: string;
  tipo: number;
}

@Injectable({ providedIn: 'root' })
export class VariableService {
  api = 'http://localhost:5010/api/variables';
  constructor(private http: HttpClient) {}
  listar(): Observable<Variable[]> { return this.http.get<Variable[]>(this.api); }
  crear(variable: Variable) { return this.http.post(this.api, variable); }
  actualizar(id: number, variable: Variable) { return this.http.put(`${this.api}/${id}`, variable); }
  eliminar(id: number) { return this.http.delete(`${this.api}/${id}`); }
}
