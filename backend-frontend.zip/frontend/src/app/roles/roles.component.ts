import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RolService, Rol } from '../services/rol.service';

@Component({
  selector: 'app-roles',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <form (ngSubmit)="guardar()" style="margin-bottom:16px;">
      <input [(ngModel)]="rol.nombre" name="nombre" placeholder="Nombre del Rol" required>
      <button type="submit">{{ editando ? 'Actualizar' : 'Agregar' }}</button>
      <button type="button" (click)="cancelar()" *ngIf="editando">Cancelar</button>
    </form>
    <table border="1" style="width:100%;">
      <tr>
        <th>Id</th>
        <th>Nombre</th>
        <th>Acciones</th>
      </tr>
      <tr *ngFor="let r of roles">
        <td>{{ r.id }}</td>
        <td>{{ r.nombre }}</td>
        <td>
          <button (click)="editar(r)">Editar</button>
          <button (click)="eliminar(r.id)">Eliminar</button>
        </td>
      </tr>
    </table>
  `,
  styles: []
})
export class RolesComponent {
  roles: Rol[] = [];
  rol: Rol = { id: 0, nombre: '' };
  editando = false;

  constructor(private rolSvc: RolService) {
    this.cargarRoles();
  }

  cargarRoles() {
    this.rolSvc.listar().subscribe(data => this.roles = data);
  }

  guardar() {
    if (!this.rol.nombre.trim()) { alert('El nombre es obligatorio'); return; }
    if (this.editando) {
      this.rolSvc.actualizar(this.rol.id, this.rol).subscribe(() => {
        this.cancelar();
        this.cargarRoles();
      });
    } else {
      this.rolSvc.crear(this.rol).subscribe(() => {
        this.cancelar();
        this.cargarRoles();
      });
    }
  }

  editar(rol: Rol) {
    this.rol = { ...rol };
    this.editando = true;
  }

  eliminar(id: number) {
    if (confirm('¿Eliminar rol?')) {
      this.rolSvc.eliminar(id).subscribe(() => this.cargarRoles());
    }
  }

  cancelar() {
    this.rol = { id: 0, nombre: '' };
    this.editando = false;
  }
}
