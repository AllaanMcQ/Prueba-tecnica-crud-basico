import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { UsuarioService, Usuario } from '../services/usuario.service';
import { RolService, Rol } from '../services/rol.service';

@Component({
  selector: 'app-usuarios',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <form (ngSubmit)="guardar()" style="margin-bottom:16px;">
      <input [(ngModel)]="usuario.nombre" name="nombre" placeholder="Nombre" required>
      <input [(ngModel)]="usuario.email" name="email" placeholder="Email" required type="email">
      <select [(ngModel)]="usuario.rolId" name="rolId" required>
        <option value="" disabled selected>Selecciona un rol</option>
        <option *ngFor="let rol of roles" [value]="rol.id">{{ rol.nombre }}</option>
      </select>
      <button type="submit">{{ editando ? 'Actualizar' : 'Agregar' }}</button>
      <button type="button" (click)="cancelar()" *ngIf="editando">Cancelar</button>
    </form>
    <table border="1" style="width:100%;">
      <tr>
        <th>Id</th>
        <th>Nombre</th>
        <th>Email</th>
        <th>Rol</th>
        <th>Acciones</th>
      </tr>
      <tr *ngFor="let u of usuarios">
        <td>{{ u.id }}</td>
        <td>{{ u.nombre }}</td>
        <td>{{ u.email }}</td>
        <td>{{ getNombreRol(u.rolId) }}</td>
        <td>
          <button (click)="editar(u)">Editar</button>
          <button (click)="eliminar(u.id)">Eliminar</button>
        </td>
      </tr>
    </table>
  `,
  styles: []
})
export class UsuariosComponent {
  usuarios: Usuario[] = [];
  roles: Rol[] = [];
  usuario: Usuario = { id: 0, nombre: '', email: '', rolId: 0 };
  editando = false;

  constructor(
    private usuarioSvc: UsuarioService,
    private rolSvc: RolService
  ) {
    this.cargarUsuarios();
    this.rolSvc.listar().subscribe(data => this.roles = data);
  }

  cargarUsuarios() {
    this.usuarioSvc.listar().subscribe(data => this.usuarios = data);
  }

  guardar() {
    if (!this.usuario.nombre.trim() || !this.usuario.email.trim() || !this.usuario.rolId) {
      alert('Todos los campos son obligatorios');
      return;
    }
    if (this.editando) {
      this.usuarioSvc.actualizar(this.usuario.id, this.usuario).subscribe(() => {
        this.cancelar();
        this.cargarUsuarios();
      });
    } else {
      this.usuarioSvc.crear(this.usuario).subscribe(() => {
        this.cancelar();
        this.cargarUsuarios();
      });
    }
  }

  editar(u: Usuario) {
    this.usuario = { ...u };
    this.editando = true;
  }

  eliminar(id: number) {
    if (confirm('¿Eliminar usuario?')) {
      this.usuarioSvc.eliminar(id).subscribe(() => this.cargarUsuarios());
    }
  }

  cancelar() {
    this.usuario = { id: 0, nombre: '', email: '', rolId: 0 };
    this.editando = false;
  }

  getNombreRol(rolId: number): string {
    const rol = this.roles.find(r => r.id === rolId);
    return rol ? rol.nombre : '';
  }
}
